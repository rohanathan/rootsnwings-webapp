"use client";

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useRouter } from 'next/navigation';

// Main component for the Mentor Detail page - Revamped with all sections
const MentorDetail = () => {
    // State management
    const [isBioExpanded, setIsBioExpanded] = useState(false);
    const [activeSessionType, setActiveSessionType] = useState('one-on-one');
    const [contactForm, setContactForm] = useState({
        subject: '',
        message: '',
        preferredTime: ''
    });

    // Enhanced mentor data with all sections from HTML
    const mentorData = {
        name: "Priya Sharma",
        profileInitials: "PS",
        rating: 4.9,
        reviews: 32,
        price: 35,
        location: "Birmingham & Online",
        languages: ["English", "Hindi", "Gujarati"],
        //responseTime: "30min",
        bio: `I'm a passionate Kathak dancer and instructor with over 10 years of experience teaching traditional Indian dance forms. Having trained under renowned masters in Mumbai and London, I bring authentic cultural knowledge combined with modern teaching methods. I specialize in helping students of all ages connect with their cultural heritage through dance, music, and storytelling. My approach focuses on building confidence while maintaining respect for traditional forms. I offer classes in Hindi, English, and Gujarati.`,
        shortBio: `I'm a passionate Kathak dancer and instructor with over 10 years of experience teaching traditional Indian dance forms. Having trained under renowned masters in Mumbai and London, I bring authentic cultural knowledge combined with modern teaching methods...`,
        badges: ["Music", "Cultural Arts", "Dance"],
        stats: [
            { icon: "✅", label: "Background Verified" },
            { icon: "⏰", label: "500+ Hours" },
            { icon: "🔄", label: "85% Repeat Students" },
            { icon: "💬", label: "Replies in 30 min" },
        ],
        qualifications: [
            {
                id: "qual_1",
                type: "degree",
                title: "Master of Arts in Kathak",
                institution: "Bharatiya Vidya Bhavan, London",
                year: "2018",
                icon: "📜"
            },
            {
                id: "qual_2",
                type: "degree", 
                title: "BA Music & Performance",
                institution: "University of Birmingham",
                year: "2015",
                icon: "🎓"
            },
            {
                id: "qual_3",
                type: "certification",
                title: "DBS Checked",
                institution: "Enhanced Disclosure",
                year: "Valid until 2025",
                icon: "⭐"
            }
        ],
        subjects: ["Kathak Dance", "Bollywood", "Folk Dance", "Music Theory", "Hindi Language"],
        teachingLevels: ["Beginner", "Intermediate", "Advanced"],
        ageGroups: ["Children (5-12)", "Teens (13-17)", "Adults (18+)"],
        availabilitySummary: {
            timezone: "Europe/London",
            generallyAvailable: ["Saturday", "Sunday"],
            preferredHours: "12:00-18:00"
        },
        sessionTypes: {
            "one-on-one": {
                title: "One-on-One Sessions",
                description: "Personalized 1-hour sessions designed around your specific learning goals and pace.",
                nature: "Flexible individual learning with personalized attention, custom curriculum, and the ability to focus on exactly what you want to learn.",
                duration: "60 minutes",
                price: "£35",
                includes: ["Personalized curriculum", "Flexible scheduling", "One-on-one attention", "Progress tracking", "Direct mentor support"],
                hasClasses: false
            },
            "group": {
                title: "Group Batches", 
                description: "Join small cohorts for structured multi-week courses with comprehensive skill development.",
                nature: "Collaborative learning environment with structured progression, weekly sessions, and peer interaction. Perfect for building skills alongside like-minded learners.",
                duration: "4-12 weeks",
                price: "Varies",
                includes: ["Structured curriculum", "Small group sizes", "Peer learning", "Weekly sessions", "Progress certificates"],
                hasClasses: true
            },
            "workshop": {
                title: "Workshops",
                description: "Intensive single-session experiences focusing on specific skills, techniques, or cultural topics.",
                nature: "Deep-dive sessions ranging from 2-8 hours, covering specialized topics with hands-on practice and cultural immersion.",
                duration: "2-8 hours",
                price: null,
                includes: ["Intensive learning", "Hands-on practice", "Cultural context", "Take-home materials", "Certificate of completion"],
                hasClasses: true
            }
        }
    };

    const handleContactSubmit = (e) => {
        e.preventDefault();
        console.log('Contact form submitted:', contactForm);
        // Handle form submission
    };

    const renderSessionTypeTab = (type, data) => {
        const isActive = activeSessionType === type;
        return (
            <button
                key={type}
                onClick={() => setActiveSessionType(type)}
                className={`px-6 py-3 font-semibold rounded-lg transition-colors ${
                    isActive 
                        ? 'bg-primary text-white' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
                {data.title}
            </button>
        );
    };

    const renderActiveSessionType = () => {
        const data = mentorData.sessionTypes[activeSessionType];
        const mentorId = 'priya'; // This would come from props/params in real implementation
        
        return (
            <div className="mt-6 p-6 bg-gray-50 rounded-xl">
                <div className="mb-4">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{data.title}</h3>
                    <p className="text-gray-600 mb-3">{data.description}</p>
                    <p className="text-gray-700 font-medium">{data.nature}</p>
                </div>
                
                <div className="mb-4">
                    <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                        <span><strong>Duration:</strong> {data.duration}</span>
                        {data.price && <span><strong>Price:</strong> {data.price}</span>}
                    </div>
                </div>
                
                <div className="space-y-2 mb-6">
                    <h4 className="font-semibold text-gray-700">What's Included:</h4>
                    {data.includes.map((item, index) => (
                        <div key={index} className="flex items-center text-sm text-gray-600">
                            <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                            {item}
                        </div>
                    ))}
                </div>
                
                <button 
                    onClick={() => {
                        // Redirect to filtered classes page
                        const filterType = activeSessionType === 'one-on-one' ? 'one-on-one' : activeSessionType;
                        window.location.href = `/classes?mentor=${mentorId}&type=${filterType}`;
                    }}
                    className="w-full bg-primary hover:bg-primary-dark text-white py-3 px-6 rounded-lg font-semibold transition-colors"
                >
                    Explore {data.title}
                </button>
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Navigation */}
            <nav className="fixed top-0 w-full z-50 bg-white/95 backdrop-blur-sm shadow-lg">
                <div className="max-w-7xl mx-auto px-5">
                    <div className="flex justify-between items-center py-4">
                        <a href="#" className="text-2xl font-bold text-primary-dark">Roots & Wings</a>
                        <div className="flex items-center space-x-6">
                            <a href="#" className="text-gray-600 hover:text-primary transition-colors">← Back to Mentors</a>
                            <a href="#" className="bg-primary hover:bg-blue-500 text-white px-4 py-2 rounded-full font-medium transition-colors">Sign Up</a>
                        </div>
                    </div>
                </div>
            </nav>

            {/* Main Content */}
            <main className="pt-20">
                <div className="max-w-7xl mx-auto px-5 py-8">
                    
                    {/* Top Section: Profile + Pricing */}
                    <div className="grid lg:grid-cols-3 gap-8 mb-8">
                        
                        {/* Mentor Profile Card */}
                        <div className="lg:col-span-2">
                            <div className="bg-white rounded-2xl p-8 shadow-lg">
                                
                                {/* Profile Header */}
                                <div className="flex items-start gap-6 mb-8">
                                    <div className="w-24 h-24 bg-primary rounded-2xl flex items-center justify-center text-white text-2xl font-bold">
                                        {mentorData.profileInitials}
                                    </div>
                                    
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-2">
                                            <h1 className="text-3xl font-bold text-gray-900">{mentorData.name}</h1>
                                            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                                                <div className="w-2 h-2 bg-white rounded-full"></div>
                                            </div>
                                        </div>
                                        
                                        <div className="flex items-center gap-4 text-gray-600 mb-4">
                                            <div className="flex items-center gap-1">
                                                <span className="text-yellow-500">★</span>
                                                <span className="font-semibold">{mentorData.rating}</span>
                                                <span>({mentorData.reviews} reviews)</span>
                                            </div>
                                            <span>•</span>
                                            <span>{mentorData.location}</span>

                                        </div>
                                        
                                        <div className="flex items-center gap-2 mb-4">
                                            <span className="text-sm text-gray-600">Languages:</span>
                                            <span className="text-sm font-medium">{mentorData.languages.join(", ")}</span>
                                        </div>
                                        
                                        <div className="flex flex-wrap gap-2 mb-6">
                                            {mentorData.badges.map((badge, index) => (
                                                <span key={index} className="px-3 py-1 bg-primary-light text-primary text-sm rounded-full font-medium">
                                                    {badge}
                                                </span>
                                            ))}
                                        </div>
                                        
                                        {/* Stats */}
                                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                            {mentorData.stats.map((stat, index) => (
                                                <div key={index} className="text-center p-3 bg-gray-50 rounded-lg">
                                                    <div className="text-2xl mb-1">{stat.icon}</div>
                                                    <div className="text-xs text-gray-600">{stat.label}</div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                {/* About Section */}
                                <div className="border-t pt-6">
                                    <h2 className="text-xl font-bold text-primary-dark mb-4">About {mentorData.name}</h2>
                                    <div>
                                        <p className="text-gray-700 leading-relaxed mb-4">
                                            {isBioExpanded ? mentorData.bio : mentorData.shortBio}
                                        </p>
                                        <button 
                                            onClick={() => setIsBioExpanded(!isBioExpanded)}
                                            className="text-primary hover:text-primary-dark font-semibold transition-colors"
                                        >
                                            {isBioExpanded ? 'Read less' : 'Read more'}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Quick Booking Card */}
                        <div className="lg:col-span-1">
                            <div className="bg-white rounded-2xl p-6 shadow-lg sticky top-24">
                                <div className="text-center mb-6">
                                    <div className="text-3xl font-bold text-primary mb-2">£{mentorData.price}</div>
                                    <div className="text-gray-600">per session</div>
                                </div>
                                
                                <div className="space-y-3 mb-6">
                                    <button className="w-full bg-primary hover:bg-primary-dark text-white py-3 px-6 rounded-lg font-semibold transition-colors">
                                        Book One-on-One Session
                                    </button>
                                    <button className="w-full border-2 border-primary text-primary hover:bg-primary hover:text-white py-3 px-6 rounded-lg font-semibold transition-colors">
                                        Join Group Class
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Two Column Layout: Availability + Reviews/Qualifications */}
                    <div className="grid lg:grid-cols-3 gap-8 mb-8">
                        
                        {/* Left Side: Availability + Session Types */}
                        <div className="lg:col-span-2 space-y-8">
                            
                            {/* Availability Snapshot */}
                            <div className="bg-white rounded-2xl p-8 shadow-lg">
                                <h2 className="text-2xl font-bold text-primary-dark mb-6">Availability Snapshot</h2>
                                
                                <div className="mb-6">
                                    <div className="flex items-center justify-between mb-4">
                                        <h3 className="font-semibold text-gray-700">Generally Available</h3>
                                        <span className="text-sm text-gray-500">{mentorData.availabilitySummary.timezone}</span>
                                    </div>
                                    
                                    <div className="flex flex-wrap gap-2 mb-4">
                                        {mentorData.availabilitySummary.generallyAvailable.map((day, index) => (
                                            <span key={index} className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full">
                                                {day}
                                            </span>
                                        ))}
                                    </div>
                                    
                                    <div className="text-sm text-gray-600">
                                        <strong>Preferred Hours:</strong> {mentorData.availabilitySummary.preferredHours}
                                    </div>
                                </div>

                                <div className="bg-gray-50 rounded-lg p-4">
                                    <p className="text-sm text-gray-600 text-center">
                                        Check out the section below for detailed availability and schedule your preferred time
                                    </p>
                                </div>
                            </div>

                            {/* Session Types */}
                            <div className="bg-white rounded-2xl p-8 shadow-lg">
                                <h2 className="text-2xl font-bold text-primary-dark mb-6">Session Types</h2>
                                
                                {/* Tab Selection */}
                                <div className="flex flex-wrap gap-3 mb-6">
                                    {Object.entries(mentorData.sessionTypes).map(([type, data]) => 
                                        renderSessionTypeTab(type, data)
                                    )}
                                </div>
                                
                                {/* Active Session Type Content */}
                                {renderActiveSessionType()}
                            </div>
                        </div>

                        {/* Right Side: Qualifications + Subjects + Contact */}
                        <div className="lg:col-span-1 space-y-8">
                            
                            {/* Qualifications */}
                            <div className="bg-white rounded-2xl p-6 shadow-lg">
                                <h2 className="text-xl font-bold text-primary-dark mb-4">Certifications & Education</h2>
                                
                                <div className="space-y-4">
                                    {mentorData.qualifications.map((qual) => (
                                        <div key={qual.id} className="border-b border-gray-100 pb-4 last:border-b-0">
                                            <div className="flex items-start gap-3">
                                                <div className="w-8 h-8 bg-primary-light rounded-lg flex items-center justify-center text-primary font-bold text-xs">
                                                    {qual.icon}
                                                </div>
                                                <div>
                                                    <h4 className="font-semibold text-gray-800">{qual.title}</h4>
                                                    <p className="text-sm text-gray-600">{qual.institution}</p>
                                                    <p className="text-sm text-gray-500">{qual.year}</p>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Subjects & Levels */}
                            <div className="bg-white rounded-2xl p-6 shadow-lg">
                                <h2 className="text-xl font-bold text-primary-dark mb-4">Subjects & Levels</h2>
                                
                                {/* Subject Areas */}
                                <div className="mb-6">
                                    <h4 className="font-semibold text-gray-700 mb-3">Subject Areas</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {mentorData.subjects.map((subject, index) => (
                                            <span key={index} className="px-3 py-1 bg-primary text-white text-sm rounded-full">
                                                {subject}
                                            </span>
                                        ))}
                                    </div>
                                </div>

                                {/* Levels */}
                                <div className="mb-6">
                                    <h4 className="font-semibold text-gray-700 mb-3">Levels</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {mentorData.teachingLevels.map((level, index) => {
                                            const colors = {
                                                "Beginner": "bg-green-100 text-green-700",
                                                "Intermediate": "bg-yellow-100 text-yellow-700", 
                                                "Advanced": "bg-red-100 text-red-700"
                                            };
                                            return (
                                                <span key={index} className={`px-3 py-1 text-sm rounded-full ${colors[level] || 'bg-gray-100 text-gray-700'}`}>
                                                    {level}
                                                </span>
                                            );
                                        })}
                                    </div>
                                </div>

                                {/* Age Groups */}
                                <div>
                                    <h4 className="font-semibold text-gray-700 mb-3">Age Groups</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {mentorData.ageGroups.map((ageGroup, index) => {
                                            const colors = {
                                                "Children (5-12)": "bg-blue-100 text-blue-700",
                                                "Teens (13-17)": "bg-purple-100 text-purple-700",
                                                "Adults (18+)": "bg-indigo-100 text-indigo-700"
                                            };
                                            return (
                                                <span key={index} className={`px-3 py-1 text-sm rounded-full ${colors[ageGroup] || 'bg-gray-100 text-gray-700'}`}>
                                                    {ageGroup}
                                                </span>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>

                            {/* Contact Mentor */}
                            {/*<div className="bg-white rounded-2xl p-6 shadow-lg">
                                <h2 className="text-xl font-bold text-primary-dark mb-4">Contact Mentor</h2>
                                
                                <form onSubmit={handleContactSubmit} className="space-y-4">
                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Subject</label>
                                        <input 
                                            type="text" 
                                            value={contactForm.subject}
                                            onChange={(e) => setContactForm({...contactForm, subject: e.target.value})}
                                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-primary focus:outline-none" 
                                            placeholder="What would you like to learn?"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Message</label>
                                        <textarea 
                                            value={contactForm.message}
                                            onChange={(e) => setContactForm({...contactForm, message: e.target.value})}
                                            rows="4" 
                                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-primary focus:outline-none" 
                                            placeholder="Tell the mentor about your goals, experience level, and what you'd like to achieve..."
                                        ></textarea>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Preferred Time</label>
                                        <select 
                                            value={contactForm.preferredTime}
                                            onChange={(e) => setContactForm({...contactForm, preferredTime: e.target.value})}
                                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-primary focus:outline-none"
                                        >
                                            <option value="">Select preferred time</option>
                                            <option value="morning">Morning (9am-12pm)</option>
                                            <option value="afternoon">Afternoon (12pm-5pm)</option>
                                            <option value="evening">Evening (5pm-8pm)</option>
                                            <option value="flexible">I'm flexible</option>
                                        </select>
                                    </div>

                                    <button 
                                        type="submit" 
                                        className="w-full bg-primary hover:bg-primary-dark text-white py-3 px-6 rounded-lg font-semibold transition-colors"
                                    >
                                        Send Message
                                    </button>
                                </form>
                            </div> */}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default MentorDetail;